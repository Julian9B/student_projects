﻿namespace staircase_designer
{
    public partial class MainPage : ContentPage
    {
        double heightOverall;
        double lengthOverall;


        public MainPage()
        {
            InitializeComponent();
        }


        private bool CalculateStaircase(double heightOverall, double lengthOverall, ref int stepsNumber, ref double stepHeight, ref double stepDepth)
        {

            double ratio = heightOverall / lengthOverall;
            double minRatio = 0.5;
            double maxRatio = 0.9;

            bool possible = ratio <= maxRatio && ratio >= minRatio;

            if (possible)
            {

                double perfectStepHeight = 20;
                double unroundedStepsNumber = (heightOverall * 100) / perfectStepHeight;

                stepsNumber = (int) Math.Round(unroundedStepsNumber);
                stepHeight = Math.Round((heightOverall * 100) / stepsNumber, 1);
                stepDepth = Math.Round((lengthOverall * 100) / (stepsNumber - 1), 1);
            }

            return possible;
        }


        private void Calculate_Clicked(object sender, EventArgs e)
        {
            int stepsNumber = 0;
            double stepHeight = 0;
            double stepDepth = 0;

            if (CalculateStaircase(heightOverall, lengthOverall, ref stepsNumber, ref stepHeight, ref stepDepth))
            {
                resultLabel.Text = $"Number of steps: {stepsNumber}\nHeight of each step: {stepHeight}cm\nDepth of each step: {stepDepth}cm";
            }
            else
            {
                resultLabel.Text = "Sorry, it is impossible to create ergonomic staircase using dimensions given by you.";
            }
        }


        private void OverallHeightEntry_TextChanged(object sender, TextChangedEventArgs e)
        {
            heightOverall = double.Parse(((Entry)sender).Text);
        }


        private void OverallLengthEntry_TextChanged(object sender, TextChangedEventArgs e)
        {
            lengthOverall = double.Parse(((Entry)sender).Text);
        }
    }
}
