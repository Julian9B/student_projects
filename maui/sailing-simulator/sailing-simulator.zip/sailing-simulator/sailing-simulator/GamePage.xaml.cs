namespace sailing_simulator;

public partial class GamePage : ContentPage
{
    int windDirection;

    public GamePage()
	{
		InitializeComponent();

        // kierunek wiatru

        Random r = new Random();
        windDirection = r.Next(0, 360);

		windLabel.Text = "The direction of wind: " + windDirection.ToString() + "�";
		directionIndicator.Rotation = windDirection;

        // wykonuj stale

        async Task RepeatMovement()
        {
            await MoveBoat();

            await RepeatMovement();
        }

        RepeatMovement();
    }

    // sterowanie ��dk�

    private void toPortsideButton_Clicked(object sender, EventArgs e)
    {
        boat.Rotation -= 2;
    }

    private void toStarboardButton_Clicked(object sender, EventArgs e)
    {
        boat.Rotation += 2;
    }

    async Task MoveBoat()
    {
        float speed = 40;   // powinna si� zmienia� w zale�no�ci od kierunku

        double rotationInRadians = Math.PI * boat.Rotation / 180;
        double mx = speed * Math.Sin(rotationInRadians);
        double my = -speed * Math.Cos(rotationInRadians);

        await boat.TranslateTo(boat.TranslationX + mx, boat.TranslationY + my, 2000, Easing.Linear);

        TrimSails();
    }

    // manipulowanie �aglami

    private void TrimSails(/* r�nica kierunk�w!!! */)
    {
        //
    }
}