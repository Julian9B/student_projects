namespace sailing_simulator;

public partial class GamePage : ContentPage
{
	int windDirection;
    bool portsideButtonPressed;

	public GamePage()
	{
		InitializeComponent();

        Random r = new Random();
        windDirection = r.Next(0, 360);

		windLabel.Text = "The direction of wind: " + windDirection.ToString() + "�";
		directionIndicator.Rotation = windDirection;
    }

    private void toPortsideButton_Clicked(object sender, EventArgs e)
    {
        boat.Rotation -= 1;
    }

    private void toStarboardButton_Clicked(object sender, EventArgs e)
    {
        boat.Rotation += 1;
    }
}