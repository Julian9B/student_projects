namespace sailing_simulator;

public partial class GamePage : ContentPage
{
	int windDirection;

	public GamePage()
	{
		InitializeComponent();

        Random r = new Random();
        windDirection = r.Next(0, 360);
		windLabel.Text = "The direction of wind: " + windDirection.ToString() + "�";
    }
}