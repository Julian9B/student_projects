﻿namespace sailing_simulator
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void startButton_Clicked(object sender, EventArgs e)
        {
            goToGame();
        }

        private async Task goToGame()
        {
            await Navigation.PushAsync(new GamePage());
        }
    }

}
