﻿namespace sailing_simulator
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            var mainWindow = Application.Current.Windows[0];
            mainWindow.Width = 1800;
            mainWindow.Height = 1000;
        }

        private void startButton_Clicked(object sender, EventArgs e)
        {
            goToGame();
        }

        private async Task goToGame()
        {
            await Navigation.PushAsync(new GamePage());
        }
    }

}
